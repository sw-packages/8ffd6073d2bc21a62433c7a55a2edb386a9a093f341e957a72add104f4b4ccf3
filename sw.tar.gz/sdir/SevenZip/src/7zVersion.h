#define MY_VER_MAJOR 9
#define MY_VER_MINOR 22
#define MY_VER_BUILD 00
#define MY_VERSION "9.22 beta"
#define MY_7ZIP_VERSION "9.22 beta"
#define MY_DATE "2011-04-18"
#define MY_COPYRIGHT ": Igor Pavlov : Public domain"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION " " MY_COPYRIGHT " : " MY_DATE
